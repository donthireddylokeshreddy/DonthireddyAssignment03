package question10;

import java.io.IOException;

public class SuperClass {
	void myMethod() throws IOException {
System.out.println("IOException from Super");

	}

}