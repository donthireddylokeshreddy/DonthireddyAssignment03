package question10;

import java.io.IOException;

public class MainDriver {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		SuperClass se = new SuperClass();
		SubClass sbi = new SubClass();
		
		
		se.myMethod();
		sbi.myMethod();
	}

}
