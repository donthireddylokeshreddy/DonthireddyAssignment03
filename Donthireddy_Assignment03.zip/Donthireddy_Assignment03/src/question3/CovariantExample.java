package question3;

public class CovariantExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		animal a = new animal();
	      Dog d = new Dog();
	      
	      // Test covariant return type
	      animal a2 = d.reproduce();
	      System.out.println(a2.getClass());

	}

}