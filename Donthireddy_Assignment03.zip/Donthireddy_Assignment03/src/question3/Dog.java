package question3;

public class Dog extends animal{
	
	@Override
	public Dog reproduce() {
	      System.out.println("Dog reproducing.");
	      return new Dog();
	   }
}
