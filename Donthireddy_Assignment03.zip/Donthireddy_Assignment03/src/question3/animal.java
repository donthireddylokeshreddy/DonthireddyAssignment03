package question3;

public class animal {
		
		public animal reproduce() {
		      System.out.println("Animal reproducing.");
		      return new animal();
		   }

	}
