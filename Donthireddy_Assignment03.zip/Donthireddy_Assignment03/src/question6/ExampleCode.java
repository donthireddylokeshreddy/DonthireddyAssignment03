package question6;

public class ExampleCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Example using String
		String stri1 = "hello";
		String stri2 = stri1.concat(" Lokesh"); 
		System.out.println(stri1);  
		System.out.println(stri2);  

		// Example using StringBuffer
		StringBuffer sbe1 = new StringBuffer("hello");
		sbe1.append(" Lokesh reddy");  
		System.out.println(sbe1);  


	}

}