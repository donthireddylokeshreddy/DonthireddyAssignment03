package question12;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FinalExample {
	   final int a = 5180;
	   
	   public void finalize() {
		      System.out.println("Object is garbage collected.");
		   }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 FinalExample obje = new FinalExample();
	      System.out.println("The value of a is: " + obje.a);
	      
	      
	      BufferedReader bre = null;
	      try {
	         bre = new BufferedReader(new FileReader("example.txt"));
	         String line;
	         while ((line = bre.readLine()) != null) {
	            System.out.println(line);
	         }
	      } catch (IOException ei) {
	         ei.printStackTrace();
	      } finally {
	         try {
	            if (bre != null)
	               bre.close();
	         } catch (IOException ei) {
	            ei.printStackTrace();
	         }
	      }
	      
	      
	      FinalExample obj1 = new FinalExample();
	      FinalExample obj2 = new FinalExample();
	      obj1 = null;
	      obj2 = null;
	      System.gc();


	}

}