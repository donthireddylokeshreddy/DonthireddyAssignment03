package question4;

public class DriverClass {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        SuperClass superex = new SuperClass();
        
        superex.staticMethod();
        superex.privateMethod();


	}

}