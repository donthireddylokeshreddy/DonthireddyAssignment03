package question4;

public class SuperClass {
	  public static void staticMethod() {
	        System.out.println("Super static method");
	    }

	    private void privateMethod() {
	        System.out.println("Super private method");
	    }


	}