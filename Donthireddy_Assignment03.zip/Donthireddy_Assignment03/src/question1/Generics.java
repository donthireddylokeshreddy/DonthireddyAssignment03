package question1;

public class Generics<D> {
	    private D value;

	    public Generics(D value) {
	        this.value = value;
	    }

	    public D getValue() {
	        return value;
	    }

	    public void setValue(D value) {
	        this.value = value;
	    }

	    public static void main(String[] args) {
	        Generics<String> stringGenerics = new Generics<>("Lokesh Reddy");
	        System.out.println("String value: " + stringGenerics.getValue());

	        Generics<Integer> integerGenerics = new Generics<>(5180);
	        System.out.println("Integer value: " + integerGenerics.getValue());
	    }

}