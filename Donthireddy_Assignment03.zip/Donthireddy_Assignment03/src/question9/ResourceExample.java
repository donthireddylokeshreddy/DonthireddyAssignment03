package question9;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ResourceExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try (BufferedReader ber = new BufferedReader(new FileReader("example.txt"))) {
		    String line;
		    while ((line = ber.readLine()) != null) {
		        System.out.println(line);
		    }
		} catch (IOException ec) {
		    System.err.println("Failed to read file: " + ec.getMessage());
		}


	}


}
