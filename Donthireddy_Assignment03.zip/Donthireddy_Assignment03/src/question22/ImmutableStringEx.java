package question22;

public class ImmutableStringEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		        String stri1 = "Hello";
		        String stri2 = stri1.concat(" World"); // Concatenating a string to str1
		        System.out.println("stri1: " + stri1); // Output: str1: Hello
		        System.out.println("stri2: " + stri2); // Output: str2: Hello World
		    
		}

	}